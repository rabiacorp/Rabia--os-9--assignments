//
//  ViewController.swift
//  Assignment2
//
//  Created by Moncef Rabia on 7/6/16.
//  Copyright © 2016 Moncef Rabia. All rights reserved.
//

import UIKit

class AppsViewController: UIViewController {
    
    
    // Mark: Declaration
    
    @IBOutlet weak var yearBorntext: UITextField!

    @IBOutlet weak var ageResult: UILabel!
    
    @IBOutlet weak var billAmounttext: UITextField!
    
    @IBOutlet weak var tipPercentagetext: UITextField!
   
    @IBOutlet weak var numberofSpotstext: UITextField!
    
    @IBOutlet weak var billSpliterResulttext: UILabel!
    
    @IBOutlet weak var guesstext: UITextField!
    
    @IBOutlet weak var guessresult: UILabel!
    

    // Mark: Actions
                     // Verify Age view
    
    @IBAction func verifyageButton(sender: UIButton) {
    }
    
    if yearBorntext.text >= 21 {
    ageResult.text = "Yay! You can drink, vote and drive."
    }
    

    if yearBorntext.text >= 18 {
    ageResult.text = "You can vote"
    }


    if yearBorn.text  >=1 6 {
    ageResult.text = "You can drive"
    }

    else {
    ageResult.text = "You are a baby"
    }
    
    // Bill Split View
    
    @IBAction func splitbillButton(sender: UIButton) {
    }
    var a: String? // Bill Amount
    var b: String? // Tip Percentage
    var c: String? // number of spots
    
     // Need to unwrapp a,b and c
if let a = a
    
    // Calculation should be: 
     // billSpliterResulttext.text = (a+b)/c
    

    
    
    // Random Number 1 to 10 View
    
    
    
    
    
    
    // MARK: Lifecycle
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view, typically from a nib.
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
}







