
import Foundation



class TodoItem {
    
    let title: String
    let description: String
    let ingredients: String
    let cookingTime: String
    
    init(title: String, description: String, ingredients: String, cookingTime: String) {
        self.title = title
        self.description = description
        self.ingredients = ingredients
        self.cookingTime = cookingTime
    }
}
