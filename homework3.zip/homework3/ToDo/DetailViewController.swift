
import UIKit

class DetailViewController: UIViewController {

    // MARK: Declaration
    
    var todoItem: TodoItem?
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    // MARK: Lifecycle
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        if let todoItem = todoItem {
            titleLabel.text = todoItem.title
            descriptionLabel.text = todoItem.description
        }
    }
}
