
import UIKit

class MainListTableViewController: UITableViewController {

    // MARK: Declaration
    
    private var todoItems = [TodoItem]()
    
    // MARK: Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        let items = [
      
            TodoItem(title: "Panna Cotta", description: "Cocoa, Cheese, Eggs, Milk, Sugar", ingredients: "Cocoa, Cheese, Eggs, Milk, Sugar", cookingTime: "10 minutes"),
            
            TodoItem(title: "Croque Monsieur", description: "Cheese, Toasted Bread, Salt, Water", ingredients: "Doritos, Cookies", cookingTime: "3 minutes"),
      
            TodoItem(title: "Chocolate Mouss", description: "Orange Zest, Dark Chocolate, Butter Milk", ingredients: "Doritos, Cookies", cookingTime: "4 minutes"),
      
        
        ]
        todoItems.appendContentsOf(items)
    }
    
    // MARK: Segue
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let detailViewController = segue.destinationViewController as? DetailViewController {
            if let indexPath = tableView.indexPathForSelectedRow {
                let todoItem = todoItems[indexPath.row]
                detailViewController.todoItem = todoItem
            }
        }
    }
    
    // MARK: UITableViewDataSource
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoItems.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCellWithIdentifier("maincellidentifier", forIndexPath: indexPath)
        
        let todoItem = todoItems[indexPath.row]
        cell.textLabel?.text = todoItem.title
        cell.detailTextLabel?.text = todoItem.description
        
        return cell
    }
}
